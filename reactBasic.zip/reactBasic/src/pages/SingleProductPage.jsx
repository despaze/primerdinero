import { useParams } from "react-router-dom"
import { products } from "../data"
import Button from "../components/Button/Button"

export default function SingleProductPage() {

    const { id } = useParams()

    const product = products.find(product => product.id === parseInt(id))

    // if(!product) {
    //     return <h2>Данные товар не был найден!</h2>
    // }

    return (
        <>
            <div className="product-page">
                <div className="productpage-item">
                    <div className="productpage-img">
                        <img src={product.photo} alt="" />
                        <div className="productimg-icons">
                            <img src={product.photo2} alt="" />
                            <img src={product.photo3} alt="" />
                            <img src={product.photo4} alt="" />
                        </div>
                    </div>
                    <div className="productpage-text">
                        <div className="productpage-zag">
                            <h1>{product.name}</h1>
                        </div>
                        <div className="productpage-subtitle">
                            <h3>{product.subtitle}</h3>
                        </div>
                        <div className="productpage-description">
                            <p>{product.description}</p>
                        </div>
                        <div className="productpage-price">
                            <p>{product.price} ₽</p>
                            <Button>В корзину</Button>
                        </div>
                    </div>
                </div>
            </div>
        
        </>
    )
}