import { useState } from "react"
import './Footer.css'
import { NavLink } from "react-router-dom"

export default function Footer(){

    const [modalIsOpen, setModalIsOpen] = useState(false)
    return(

        <footer> 
            <div className="container">

        <div class="footer"> 
 
        <div className="logo">

<a href="">

<p className="SA">western</p>
<p className="FQ">spirit</p>

</a>
</div> 
 
            <div class="footer-a"> 
                <NavLink><a href="#">Каталог</a></NavLink> 
                <a href="#">О нас</a> 
                <a href="#">Контакты</a> 
            </div> 
 
            <div class="footer-info"> 
                <p>ИП WISDOM</p> 
                <p>ИНН 165915518655</p> 
                <p>ОГРНИП 321169000154221</p> 
                <p>Казань, Бари Галеева 3А</p> 
            </div> 
 
            <div class="footer-info-time"> 
                <p>Режим работы:</p> 
                <p>вт - пт 10:00-19:00</p> 
                <p>сб 10:00-16:00</p> 
                <p> вс, пн - выходные дни</p> 
                <a href="#">+7 (880) 555-35-35</a> 
            </div> 
 
        </div> 
            </div>
    
    </footer>
)
}