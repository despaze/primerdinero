import "./Partner.css"

export default function Partner({ photo }) {
    return (
        <>
        
            <div className="partner-img">
                <img src={photo} alt="img" />
            </div>
        
        </>
    )
}