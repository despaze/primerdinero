import "./ModalContent.css"
import photo from '/public/products/product.jpg'

export default function ModalContent({ closeModal }) {
    
    return (
        <>
        
        <div className="ReactModal__Content">

            <div className="modalcart">
                <div className="modalcart-zag">
                    <h2>Корзина</h2>
                </div>
                <div className="modalcart-items">
                    <div className="modalcart-item">
                        <div className="modalcart-img">
                            <img src={photo} alt="" />
                        </div>
                        <div className="modalcart-text">
                        <h3>Название типо</h3>
                        <div className="modalcart-subtitle">
                        <p>Описание типо</p>
                        <p>Описание типо</p>

                        </div>
                        </div>
                        <div className="modalcart-price">
                            <p>100 ₽</p>
                            <a href="#" className="accc">купить</a>
                            <a href="#" className="delll">удалить</a>
                        </div>
                    </div>
                    <div className="modalcart-item">
                        <div className="modalcart-img">
                            <img src={photo} alt="" />
                        </div>
                        <div className="modalcart-text">
                        <h3>Название типо</h3>
                        <div className="modalcart-subtitle">
                        <p>Описание типо</p>
                        <p>Описание типо</p>

                        </div>
                        </div>
                        <div className="modalcart-price">
                            <p>100 ₽</p>
                            <a href="#" className="accc">купить</a>
                            <a href="#" className="delll">удалить</a>
                        </div>
                    </div>
                    <div className="modalcart-item">
                        <div className="modalcart-img">
                            <img src={photo} alt="" />
                        </div>
                        <div className="modalcart-text">
                        <h3>Название типо</h3>
                        <div className="modalcart-subtitle">
                        <p>Описание типо</p>
                        <p>Описание типо</p>

                        </div>
                        </div>
                        <div className="modalcart-price">
                            <p>100 ₽</p>
                            <a href="#" className="accc">купить</a>
                            <a href="#" className="delll">удалить</a>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div className="modalcart-btn">
                <button onClick={closeModal}>Закрыть</button>
            </div>

        </div>
        
        </>
    )
}